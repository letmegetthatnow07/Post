"use client"

export function Declaration() {
  return (
    <div className="space-y-4">
      <h3 className="bg-secondary px-4 py-3 text-lg font-bold text-foreground">
        Declaration
      </h3>
      <ol className="list-decimal space-y-3 pl-8 text-sm leading-relaxed text-foreground">
        <li>
          The option(s) exercised above by me are final. I am also fully aware
          that no change in the Order of Preference(s) in the option(s) exercised
          by me above would be permitted after the period specified for obtaining
          option is over.
        </li>
        <li>
          While giving preference for the posts mentioned at Para 15.9 of the
          Notice of Examination viz. Inspector (Central Excise/
          Examiner/Preventive Officer), Inspector and Sub-Inspector in CBN
          (Ministry of Finance), Sub-Inspector/ Junior Intelligence Officer in NCB
          (MHA), Sub-Inspector in CBI and NIA etc., I have gone through the
          specific requirement of Physical Standards, Physical Tests and Medical
          Standards, details of which is given at Annexure-XVI of the Notice of
          Examination. I fully understand that physical and medical standards will
          be ascertained by the User Departments / Organizations after the
          declaration of Final Result. I also understand that the SSC makes the
          final allocation of posts in accordance with Merit-cum-Preference of the
          candidate and once a post is allotted, no change is made by the
          Commission for any reason whatsoever. Accordingly, if I am selected and
          nominated for any of these posts and subsequently fail in the Physical
          Standards/ Physical Tests / Medical Standards, I am aware that I will not
          be considered for any other post/ Ministries/
          Departments/Organizations.
        </li>
        <li>
          I have gone through the eligibility criteria in respect of Educational
          Qualification, Age, caste/ category certificate, PwBDs certificate, etc.
          as prescribed in the notice of examination for the post(s) opted by me.
        </li>
        <li>
          I certify that I hold the requisite certificates in support of my claim
          in this regard and undertake to produce the same as and when required
          including at the time of Document Verification by the concerned User
          Department / Organization allocated to me after declaration of final
          result. I understand that the post/ Department allocated to me would be
          final and any failure on my part to produce the requisite documents of
          eligibility in support of my candidature would lead to cancellation of my
          candidature and there would be no further consideration of my candidature
          for any other post/ Department even though I might be fulfilling the
          eligibility criteria for the latter preferences.
        </li>
        <li>
          I also understand that if any in-congruence between my declaration in
          application form/ Optioncum-Preference Form and requisite documents is
          found at any stage, my candidature is liable to be rejected.
        </li>
        <li>
          {"I understand that the option-cum-preference exercised by me is final and "}
          <strong>NO</strong>
          {" subsequent changes therein would be allowed after prescribed period given by the Commission for exercising the Option-Cum-Preference."}
        </li>
        <li>
          I understand that any claim of my candidature after such rejection will
          not be considered and also that the Commission would not entertain any
          representation submitted through email, post, fax, etc. against such
          rejection.
        </li>
      </ol>
    </div>
  )
}
